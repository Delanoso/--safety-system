import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { MODULES } from "@/lib/module-access";
import { drillTypeLabel } from "@/lib/emergency-drills";
import { permitTypeLabel } from "@/lib/site-safety";
import { computeContractorCompliance } from "@/lib/contractor-compliance";

export const dynamic = "force-dynamic";

export type SearchHit = {
  category: string;
  title: string;
  subtitle?: string;
  href: string;
};

const TAKE = 8;

function companyFilter(companyId: string | null | undefined, role: string) {
  if (role === "super" || !companyId) return {};
  return { companyId };
}

export async function GET(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const url = new URL(req.url);
    const q = url.searchParams.get("q")?.trim() ?? "";
    if (q.length < 2) {
      return NextResponse.json({ query: q, results: [] });
    }

    const cf = companyFilter(user.companyId, user.role);
    const term = q;
    const results: SearchHit[] = [];

    const [
      incidents,
      medicals,
      certificates,
      contractors,
      people,
      compliance,
      toolboxTalks,
      inductions,
      visitors,
      permits,
      drills,
      riskAssessments,
      appointments,
    ] = await Promise.all([
      prisma.incident.findMany({
        where: {
          ...cf,
          OR: [
            { title: { contains: term, mode: "insensitive" } },
            { employee: { contains: term, mode: "insensitive" } },
            { description: { contains: term, mode: "insensitive" } },
            { department: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { date: "desc" },
        select: { id: true, title: true, employee: true, date: true },
      }),
      prisma.medical.findMany({
        where: {
          ...cf,
          OR: [
            { employee: { contains: term, mode: "insensitive" } },
            { medicalType: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { issueDate: "desc" },
        select: { id: true, employee: true, medicalType: true },
      }),
      prisma.certificate.findMany({
        where: {
          ...cf,
          OR: [
            { employee: { contains: term, mode: "insensitive" } },
            { certificateName: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { issueDate: "desc" },
        select: { id: true, employee: true, certificateName: true },
      }),
      prisma.contractor.findMany({
        where: {
          ...cf,
          OR: [
            { name: { contains: term, mode: "insensitive" } },
            { contactEmail: { contains: term, mode: "insensitive" } },
            { jobDescription: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { createdAt: "desc" },
        select: { id: true, name: true, documents: { select: { section: true } }, excludedSections: true },
      }),
      user.companyId
        ? prisma.companyPerson.findMany({
            where: {
              companyId: user.companyId,
              OR: [
                { name: { contains: term, mode: "insensitive" } },
                { surname: { contains: term, mode: "insensitive" } },
                { employeeNumber: { contains: term, mode: "insensitive" } },
                { idNumber: { contains: term, mode: "insensitive" } },
              ],
            },
            take: TAKE,
            select: { id: true, name: true, surname: true, employeeNumber: true },
          })
        : Promise.resolve([]),
      prisma.legalComplianceItem.findMany({
        where: {
          ...cf,
          OR: [
            { requirement: { contains: term, mode: "insensitive" } },
            { legislation: { contains: term, mode: "insensitive" } },
            { auditRef: { contains: term, mode: "insensitive" } },
            { section: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        select: { id: true, requirement: true, auditRef: true },
      }),
      prisma.toolboxTalk.findMany({
        where: {
          ...cf,
          OR: [
            { title: { contains: term, mode: "insensitive" } },
            { topic: { contains: term, mode: "insensitive" } },
            { presenter: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { talkDate: "desc" },
        select: { id: true, title: true, talkDate: true },
      }),
      prisma.inductionTraining.findMany({
        where: {
          ...cf,
          OR: [
            { employee: { contains: term, mode: "insensitive" } },
            { inductionType: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { issueDate: "desc" },
        select: { id: true, employee: true, inductionType: true },
      }),
      prisma.visitorRegisterEntry.findMany({
        where: {
          ...cf,
          OR: [
            { visitorName: { contains: term, mode: "insensitive" } },
            { hostName: { contains: term, mode: "insensitive" } },
            { visitorCompany: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { checkInAt: "desc" },
        select: { id: true, visitorName: true, hostName: true, checkInAt: true },
      }),
      prisma.permitToWork.findMany({
        where: {
          ...cf,
          OR: [
            { title: { contains: term, mode: "insensitive" } },
            { permitNumber: { contains: term, mode: "insensitive" } },
            { location: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { startDate: "desc" },
        select: { id: true, title: true, permitType: true, permitNumber: true },
      }),
      prisma.emergencyDrill.findMany({
        where: {
          ...cf,
          OR: [
            { title: { contains: term, mode: "insensitive" } },
            { coordinator: { contains: term, mode: "insensitive" } },
            { location: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { drillDate: "desc" },
        select: { id: true, title: true, drillType: true, drillDate: true },
      }),
      prisma.riskAssessment.findMany({
        where: {
          ...cf,
          OR: [
            { title: { contains: term, mode: "insensitive" } },
            { department: { contains: term, mode: "insensitive" } },
            { location: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { createdAt: "desc" },
        select: { id: true, title: true, riskLevel: true },
      }),
      prisma.appointment.findMany({
        where: {
          ...cf,
          OR: [
            { type: { contains: term, mode: "insensitive" } },
            { appointee: { contains: term, mode: "insensitive" } },
            { appointer: { contains: term, mode: "insensitive" } },
            { department: { contains: term, mode: "insensitive" } },
          ],
        },
        take: TAKE,
        orderBy: { date: "desc" },
        select: { id: true, type: true, appointee: true, date: true },
      }),
    ]);

    for (const i of incidents) {
      results.push({
        category: "Incidents",
        title: i.title,
        subtitle: i.employee ?? undefined,
        href: `/incidents/view/${i.id}`,
      });
    }
    for (const m of medicals) {
      results.push({
        category: "Medicals",
        title: `${m.employee} — ${m.medicalType}`,
        href: `/medicals/list`,
      });
    }
    for (const c of certificates) {
      results.push({
        category: "Training",
        title: `${c.employee} — ${c.certificateName}`,
        href: `/training/certificates/list`,
      });
    }
    for (const c of contractors) {
      const comp = computeContractorCompliance(c.documents, c.excludedSections);
      results.push({
        category: "Contractors",
        title: c.name,
        subtitle: `Safety file ${comp.percentage}% complete`,
        href: `/contractors/${c.id}`,
      });
    }
    for (const p of people) {
      results.push({
        category: "Staff Members",
        title: [p.name, p.surname].filter(Boolean).join(" "),
        subtitle: p.employeeNumber ? `#${p.employeeNumber}` : undefined,
        href: `/users#staff-members`,
      });
    }
    for (const item of compliance) {
      results.push({
        category: "Legal Compliance",
        title: item.requirement.slice(0, 120),
        subtitle: item.auditRef ?? undefined,
        href: `/legal-compliance/${item.id}`,
      });
    }
    for (const t of toolboxTalks) {
      results.push({
        category: "Toolbox Talks",
        title: t.title,
        subtitle: new Date(t.talkDate).toLocaleDateString(),
        href: `/toolbox-talks/${t.id}`,
      });
    }
    for (const ind of inductions) {
      results.push({
        category: "Induction Training",
        title: `${ind.employee} — ${ind.inductionType}`,
        href: `/induction-training/list`,
      });
    }
    for (const v of visitors) {
      results.push({
        category: "Visitor Register",
        title: v.visitorName,
        subtitle: `Host: ${v.hostName}`,
        href: `/visitor-register/list`,
      });
    }
    for (const p of permits) {
      results.push({
        category: "Permit to Work",
        title: p.title,
        subtitle: permitTypeLabel(p.permitType),
        href: `/permit-to-work/${p.id}`,
      });
    }
    for (const d of drills) {
      results.push({
        category: "Emergency Drills",
        title: d.title,
        subtitle: drillTypeLabel(d.drillType),
        href: `/emergency-drills/${d.id}`,
      });
    }
    for (const r of riskAssessments) {
      results.push({
        category: "Risk Assessments",
        title: r.title,
        subtitle: r.riskLevel,
        href: `/risk-assessments/${r.id}`,
      });
    }
    for (const a of appointments) {
      results.push({
        category: "Appointments",
        title: `${a.type} — ${a.appointee}`,
        href: `/appointments/view/${a.id}`,
      });
    }

  const qLower = q.toLowerCase();
  for (const mod of MODULES) {
    if (
      mod.label.toLowerCase().includes(qLower) ||
      mod.slug.includes(qLower)
    ) {
      const href =
        mod.slug === "inspections"
          ? "/inspections/select-department"
          : mod.slug === "dashboard"
            ? "/dashboard"
            : mod.slug === "notifications"
              ? "/dashboard/notifications"
              : mod.slug === "docs"
                ? "/dashboard/docs/safety-files"
                : `/${mod.slug}`;
      if (!results.some((r) => r.href === href && r.category === "Modules")) {
        results.push({ category: "Modules", title: mod.label, href });
      }
    }
  }

    return NextResponse.json({ query: q, results });
  } catch (err) {
    console.error("Search error:", err);
    return NextResponse.json({ error: "Search failed", results: [] }, { status: 500 });
  }
}
